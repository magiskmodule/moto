#!/system/bin/sh
#
# Copyright (C) 2021-2022 Matt Yang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

BASEDIR="$(dirname $(readlink -f "$0"))"
. $BASEDIR/pathinfo.sh
. $BASEDIR/libsysinfo.sh

# $1:error_message
abort() {
    echo "$1"
    echo "! Uperf installation failed."
    exit 1
}

# $1:file_node $2:owner $3:group $4:permission $5:secontext
set_perm() {
    chown $2:$3 $1
    chmod $4 $1
    chcon $5 $1
}

# $1:directory $2:owner $3:group $4:dir_permission $5:file_permission $6:secontext
set_perm_recursive() {
    find $1 -type d 2>/dev/null | while read dir; do
        set_perm $dir $2 $3 $4 $6
    done
    find $1 -type f -o -type l 2>/dev/null | while read file; do
        set_perm $file $2 $3 $5 $6
    done
}

install_uperf() {
    echo "- Finding platform specified config"
    echo "- ro.board.platform=$(getprop ro.board.platform)"
    echo "- ro.product.board=$(getprop ro.product.board)"

    local target
    local cfgname
    target="$(getprop ro.board.platform)"
    cfgname="$(get_config_name $target)"
    if [ "$cfgname" == "unsupported" ]; then
        target="$(getprop ro.product.board)"
        cfgname="$(get_config_name $target)"
    fi

    if [ "$cfgname" == "unsupported" ] || [ ! -f $MODULE_PATH/config/$cfgname.json ]; then
        abort "! Target [$target] not supported."
    fi

    echo "- Uperf config is located at $USER_PATH"
    mkdir -p $USER_PATH
    mv -f $USER_PATH/uperf.json $USER_PATH/uperf.json.bak
    cp -f $MODULE_PATH/config/$cfgname.json $USER_PATH/uperf.json
    [ ! -e "$USER_PATH/perapp_powermode.txt" ] && cp $MODULE_PATH/config/perapp_powermode.txt $USER_PATH/perapp_powermode.txt
    rm -rf $MODULE_PATH/config
    set_perm_recursive $BIN_PATH 0 0 0755 0755 u:object_r:system_file:s0
}

install_gpudec() {
    echo ""
    echo "* 请选择是否安装 双降压模块 ？"
    sleep 0.1
    echo ""
    echo "* 作者 @嘟嘟"
    sleep 0.1
    echo "* 作者 @HamJTY"
    
    sleep 0.1
    echo ""
    echo "* 单击 音量上键 确认安装。 "
    sleep 0.1
    echo "* 单击 音量下键 取消安装。"
    sleep 0.1
    echo ""
    key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
           echo ""
            echo "- 您已确认安装。"
            sleep 0.1
            echo "- 正在为您安装。️"
            echo ""
            magisk --install-module "$MODULE_PATH"/modules/gpudec.zip
            sleep 0.1
            magisk --install-module "$MODULE_PATH"/modules/cpudec.zip
            sleep 0.1
            echo ""
            echo "- 已成功为您安装双降压模块！"
            echo ""
        ;;
        *)
            sleep 0.1
            echo ""
            echo "- 已为您取消安装双降压模块！"
            echo ""
    esac
    rm -rf "$MODULE_PATH"/modules/GpuDec.zip
    rm -rf "$MODULE_PATH"/modules/CpuDec.zip
}

install_mtkgt() {
    echo ""
    echo "* 请选择是否安装 Extreme_gt_mtk模块 ？"
    sleep 0.1
    echo "* 此模块将去除厂家预设的性能调节设定。"
    sleep 0.1
    echo "* 常用于配合第三方性能调节方案使用。"
    sleep 0.1
    echo ""
    echo "* 作者 @嘟嘟"
    sleep 0.1
    echo ""
    echo "* 单击 音量上键 确认安装。"
    sleep 0.1
    echo "* 单击 音量下键 取消安装。"
    sleep 0.1
    echo ""
    key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
           echo ""
            echo "- 您已确认安装。"
            sleep 0.1
            echo "- 正在为您安装。"
            echo ""
            magisk --install-module "$MODULE_PATH"/modules/mtkgt.zip
            sleep 0.1
            echo ""
            echo "*- 已成功为您安装Extreme_gt_mtk模块！"
            echo ""
        ;;
        *)
            sleep 0.1
            echo ""
            echo "- 已为您取消安装Extreme_gt_mtk模块！"
            echo ""
    esac
    rm -rf "$MODULE_PATH"/modules/mtkgt.zip
}

check_asopt() {
    echo ""
    echo "* 请按游戏需求安装合适版本 Asoulopt 游戏线程模块。"
    sleep 0.1
    echo "* 需搭配此模块优化游戏线程放置，提升整体游戏流畅度。"
    sleep 0.1
    echo ""
    echo "* 作者 @nakixii"
    sleep 0.1
    echo ""
    echo "* 单击 音量上键 安装更适合 MOBA 类游戏版本。"
    sleep 0.1
    echo "* 单击 音量下键 安装更适合 FPS 类游戏版本。"
    sleep 0.1
    echo ""
    key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
           echo ""
            echo "- 您已确认安装。"
            sleep 0.1
            echo "- 正在为您安装。"
            echo ""
            magisk --install-module "$MODULE_PATH"/modules/asoulopt41.zip
            sleep 0.1
            echo ""
            echo "- 已成功为您安装更适合 MOBA 类游戏版本！"
            echo ""
        ;;
        *)
            sleep 0.1
            echo ""
            echo "- 已成功为您安装更适合 FPS 类游戏版本！"
            echo ""
            magisk --install-module "$MODULE_PATH"/modules/asoulopt37.zip
    esac
    rm -rf "$MODULE_PATH"/modules/asoulopt41.zip
    rm -rf "$MODULE_PATH"/modules/asoulopt37.zip     
}

fix_module_prop() {
    mkdir -p /data/adb/modules/uperf/
    cp -f "$MODULE_PATH/module.prop" /data/adb/modules/uperf/module.prop
}

unlock_limit(){
if [[ ! -d $MODPATH/system/vendor/etc/perf/ ]];then
  dir=$MODPATH/system/vendor/etc/perf/
  mkdir -p $dir
fi

for i in ` ls /system/vendor/etc/perf/ `
do
  touch $dir/$i 
done
}

echo ""
install_uperf
#unlock_limit
#install_corp

install_gpudec
install_mtkgt
check_asopt
sleep 0.2
echo ""
echo "* 安装完成，请重启，所有模块将在重启后生效！"
echo ""
fix_module_prop